<?php  include("header.php");  ?>
 <?php
    echo("<script src='jquery-ui.min.js'></script>");
	echo("<script src='jquery-3.4.1.min.js'></script>");
	
	echo("<style>");
	echo("div{display:none}");
    echo("</style>");
	
	echo("<script>");
	echo("$(document)".".ready(function (){");
	echo("$('".".A')".".click(function (){");
	echo("$('".".div1')".".slideDown();");		
	echo("});");
	echo("$('".".B')".".click(function (){");
	echo("$('".".div1')".".slideUp();");
	echo("});");
	echo("});");   
    echo("</script>");
 ?>
<?php

        $productid=$_REQUEST['data'];
        $con=mysqli_connect("localhost:3306","root","","shoppingappdb");
		if($con)
		{
			$query="select * from products where categories_id like $productid";
			$result=mysqli_query($con,$query);
			
			while($r=mysqli_fetch_assoc($result))
			{
				echo("<a href="."addtocart.php?selectproduct=".$r['product_id'].">".$r['product_name']."</a> ");
				echo(" <a href='#div1' class='A'>view details</a><br/>");
				echo("<div class='div1'>");
				echo("<br/>Product description : ".$r['product_description']);
				echo("<br/>Product price : ".$r['price']);
				echo("<br/><a href='#div1' class='B'>Hide Details</a>");
				echo("</div>");
			}

			mysqli_close($con);
		}
         echo("<br/><a href='categories.php'>View more products</a>");


?>