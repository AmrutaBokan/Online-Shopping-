<?php

	$uid=$_REQUEST['uid'];
	$fname=$_REQUEST['fname'];
	$lname=$_REQUEST['lname'];
	$contact=$_REQUEST['contact'];
	$email=$_REQUEST['email'];
	$address=$_REQUEST['address'];
	$password=$_REQUEST['password'];
	 
	
	
	move_uploaded_file($_FILES["uploadphoto"]["tmp_name"],"imgs/".$uid.".jpg");
	$con=mysqli_connect("localhost:3306","root","","shoppingappdb");
	if($con)
	{
		$query="insert into users values('$uid','$password','$fname','$lname',$contact,'$email','$address');";
		if(mysqli_query($con,$query))
		{
			echo("Registered Successfully");
			echo("<a href='login.php'>do you wanna login?</a>");
		}
		mysqli_close($con);
	}
	else
	{
		echo("connection fail");
	}


?>