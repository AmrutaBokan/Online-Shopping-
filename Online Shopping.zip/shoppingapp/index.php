<html>
	<head><title>Welcome to online shopping</title></head>
	<body>
		<h1>Welcome to online shopping</h1>
		<a href='login.php'>Login?</a>
	    
	</body>
</html>
