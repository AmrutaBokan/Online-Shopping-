<?php  include("header.php");  ?>
<?php
	
	$con=mysqli_connect("localhost:3306","root","","shoppingappdb");
	if($con)
	{
		$total=0;
		echo("<table border='1'>");
		echo("<tr><th>Product id</th><th>Product Name</th><th>Product Description</th><th>Price</th></tr>");
		foreach($_SESSION['cart'] as $pi)
		{
			$query="select * from products where product_id like $pi;";
			$result=mysqli_query($con,$query);
	
			while($r=mysqli_fetch_assoc($result))
			{
				echo("<tr><td>".$r['product_id']."</td><td>".$r['product_name']."</td><td>".$r['product_description']."</td><td>".$r['price']."</td></tr>");
			    $total= $total+$r['price'];
			}
			
		}
		$_SESSION["totalprice"]=$total;
		echo("<tr><td colspan='3'>Total</td><td>$total</td></tr>");
	   	echo("</table>");
		echo("<a href='categories.php'>View More Products?</a>");
		echo("<br/><a href='confirm.php'>Cofirm Products</a>");
		mysqli_close($con);
	}

?>