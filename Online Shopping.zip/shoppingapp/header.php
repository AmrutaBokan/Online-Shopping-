<?php session_start();  ?>
<?php
 if(isset($_SESSION['fullname']))
 {
	  echo("<b>Welcome ". $_SESSION['fullname']."</b>");
	  echo("<img src="."imgs/".$_SESSION['userid'].".jpg"." width='60' height='60' alt='image not available' style='float:left'/>");
      echo("<br/><br/><br/><hr/>");
 }
 else
 {
	 echo("<hr/><b> Welcome Guest....!!!</b>");
 }
 
 ?>
