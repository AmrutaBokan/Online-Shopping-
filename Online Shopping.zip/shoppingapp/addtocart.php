<?php  include("header.php");  ?>
<?php
	$selectproduct=$_REQUEST['selectproduct'];
    if(isset($_SESSION['cart']))
	{
		array_push($_SESSION['cart'],$selectproduct);
	}
	else
	{
		$_SESSION['cart']=array($selectproduct);
	}
    echo("<br/>Product Selected is ".$selectproduct);
	echo("<br/><a href='viewcart.php'>View Cart</a>");
	echo("<br/><a href='categories.php'>View more products</a>");

?>