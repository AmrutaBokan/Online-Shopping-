<?php  session_start(); ?>
<?php
  $dt=date("Y-m-d h:i:s");
  $uv=$_SESSION['userid'];
  $logindate=$_SESSION['logindate'];
  $con=mysqli_connect("localhost:3306","root","","shoppingappdb");
  if($con)
  {
	$query="update log SET logout_date='$dt' where user_id='$uv' and login_date='$logindate' ;";
	mysqli_query($con,$query);
	mysqli_close($con);
  }
  session_destroy();
 
  echo("Logout Sucessfully");
  echo("<br/><a href='index.php'>Do you wanna visit again?</a>");


?>
