
<html>
	<head><title>Categories</title></head>
	<body>
	   <?php include("header.php"); ?>
	   <h1>All Categories</h1>
	   <?php
		   $con=mysqli_connect("localhost:3306","root","","shoppingappdb");
		   if($con)
		   {
			   $query="select * from categories";
			   $result=mysqli_query($con,$query);
			   while($r=mysqli_fetch_assoc($result))
			   {
				    $ci=$r['categories_id'];   
					$cn=$r['categories_name']; 
					
					echo("<br/><a href='selectproduct.php?data=$ci' >".$cn."</a><br/>");
			   }
			   
		   
		      mysqli_close($con);
		    }
	  ?>
	</body>
</html>	
