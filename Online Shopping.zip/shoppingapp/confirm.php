
<?php  include("header.php");  ?>
<?php
	$totalprice=$_SESSION["totalprice"];
	$uid=$_SESSION['userid'];			
	$date=date("Y-m-d");
	echo("Bill is generated <br/>");
	echo("<br/>Bill will be mailed at ".$_SESSION['email']);	
	echo("<br/>You will receive the message before delivery on ".$_SESSION['contact']);
	echo("<br/>Products delivery to ".$_SESSION['address']." address");
	echo("<br/>Total product price ".$totalprice);
     
	$subject='You products are confirmed. Thanks For Online shopping';
	$message='Total price of product is '.$totalprice;
	$message.='Products delivery to '.$_SESSION['address']." address";
	$header='From: bokanamruta@gmail.com';
	$to=$_SESSION['email'];
	if(mail($to,$subject,$message,$header))
		echo("<br/>mail sent succefully");
    
	$con=mysqli_connect("localhost:3306","root","","shoppingappdb");
	if($con)
	{
		$query="insert into shopping(suserid,sdate,totalprice) values('$uid','$date',$totalprice);";
		if(mysqli_query($con,$query))
		    echo("<br/>Shopping summary is inserted");
		mysqli_close($con);
	}
	echo("<br/><a href='logout.php'>Logout?</a>");
	
	
	

?>