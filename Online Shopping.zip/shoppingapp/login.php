
<!DOCTYPE html>

<?php   include("header.php"); ?>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Shopping app login</title>
</head>
<body>
 
    <form action="logincheck.php" method="get">
        <table>
            <tr>
               <td><label>User Name</label></td>
               <td><input type="text" name="uname" id="uname" required /></td>
               
            </tr>
            <tr>
                <td><label>Password</label></td>
                <td><input type="password" name="password" id="pass" required/></td>
               
            </tr>
			<tr>
				<?php
					if(isset($_COOKIE['loginerror']))
					{
						echo("<td style='color:brown'>".$_COOKIE['loginerror']."</td>");
					}
				?>
			</tr>
            <tr>
                <td><input type="submit" value="Login" /></td>
                <td><input type="reset" value="Cancel" /></td>
            </tr>
        </table>
		<a href="registerlogin.html">New User?Register Here</a>
    </form>
	

</body>
</html>