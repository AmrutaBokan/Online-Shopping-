	<script src='jquery-3.4.1.min.js'></script>
	<script src='jquery-ui.min.js'></script>
	<script>
	$(document).ready(function (){
		$('.A').click(function (){
			$('#div1').slideDown();		
		});
		$('#B').click(function (){$('#div1').slideUp();});
	});
    </script>