<?php session_start();   ?>
<html>
	<head><title>logincheck</title></head>
	<body>
	<?php
		$uname=$_REQUEST['uname'];
		$password=$_REQUEST['password'];
		
		$con=mysqli_connect("localhost:3306","root","","shoppingappdb");
		if($con)
		{
			$query="select * from users where userid='$uname' and password='$password';";
			$result=mysqli_query($con,$query);
			$n=mysqli_num_rows($result);
			if($n==1)
			{
				
				while($r=mysqli_fetch_assoc($result))
				{
					$fulln=$r['firstname']."  ".$r['lastname'];
					$_SESSION['fullname']=$fulln;
					$_SESSION['fname']=$r['firstname'];	
					$_SESSION['lname']=$r['lastname'];					
					$_SESSION['contact']=$r['contactnumber'];
					$_SESSION['email']=$r['email'];
					$_SESSION['address']=$r['address'];
					$_SESSION['userid']=$r['userid'];
				}
				
				setcookie("loginerror"," ",time()-100);
				header("Location:categories.php");
				$uv=$_SESSION['userid'];
				$dt=date("Y-m-d h:i:s");
				$_SESSION['logindate']=$dt;
				$query1="insert into log(user_id,login_date,logout_date) values('$uv','$dt','null');";
				mysqli_query($con,$query1);
			}
			else
			{
				setcookie("loginerror","please enter correct uname and password",time()+120);
				header("Location:login.php");
			}
			mysqli_close($con);
		}
	?>
	</body>
</html>